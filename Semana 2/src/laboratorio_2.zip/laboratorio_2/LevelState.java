package laboratorio_2;

public enum LevelState {
    NOT_ANSWERED, CORRECT, FAILED
}
