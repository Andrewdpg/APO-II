package laboratorio_2;

public enum Operation {
    ADDITION, SUBSTRACTION, DIVISION, MULTIPLICATION
}
